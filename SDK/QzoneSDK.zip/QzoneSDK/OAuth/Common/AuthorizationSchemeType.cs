﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QzoneSDK.OAuth.Common
{
    public enum AuthorizationSchemeType
    {
        Unknown
        ,
        Header
            ,
        QueryString
            , Body
    }
}
