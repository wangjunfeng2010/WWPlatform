﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QzoneSDK.OAuth.Common
{
    public enum SignatureMethodType
    {
        PLAINTEXT
        ,
        HMAC_SHA1
        , RSA_SHA1
    }
}
