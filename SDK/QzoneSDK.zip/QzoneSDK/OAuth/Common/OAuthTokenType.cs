﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QzoneSDK.OAuth.Common
{
    public enum OAuthTokenType
    {
        Unknown = 0,
        RequestToken = 1,
        AccessToken = 2,
        AccessTokenEx = 3,
    }
}
