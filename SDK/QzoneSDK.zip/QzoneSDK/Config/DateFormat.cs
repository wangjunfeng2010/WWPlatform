﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QzoneSDK.Config
{
    public enum DateFormat
    {
        ISO8601 = 1,
        GMT = 2,
        EPOCH = 3,
        UTC = 4
    }
}
